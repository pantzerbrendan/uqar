#include "Accounts/RegularAccount.hh"

RegularAccount::RegularAccount(User *owner, u_int id) : A_Account(owner, id) {

}

RegularAccount::~RegularAccount() {

}
