
#ifndef UTILS_H_
#define UTILS_H_

namespace utils
{

int 		pgcd(int, int);

}

#endif /* !UTILS_H_ */